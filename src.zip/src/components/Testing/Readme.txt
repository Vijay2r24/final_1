This folder should be deleted in the production build. This is for testing purpose only.
~Shiwang